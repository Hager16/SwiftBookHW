//: [Назад: Задание 2](@previous)
import UIKit
let dayOfBirth = 16
let monthOfBirth = 5
let yearOfBirth = 2000
// Today is 6.11.2020
let yearsPassed = 2020 - yearOfBirth
let monthsPassed = yearsPassed * 12 + 11
let daysPassed = monthsPassed * 30
let secondsPassed = daysPassed * 24 * 60 * 60
let allTimePassedString = "\(yearsPassed) years or \(monthsPassed) months or \(daysPassed) days or \(secondsPassed) seconds have passed since my birth"
print(allTimePassedString)
let firstQuarter = 1...3
let secondQuarter = 4...6
let thirdQuarter = 7...9
let fourthQuarter = 10...12
if firstQuarter ~= monthOfBirth {
 print("I was born in the first quarter of the year")
}
else if secondQuarter ~= monthOfBirth {
    print("I was born in the second quarter of the year")
}
else if thirdQuarter ~= monthOfBirth {
    print("I was born in the third quarter of the year")
}
else if fourthQuarter ~= monthOfBirth {
    print("I was born in the fourth quarter of the year")
}
//: [Далее: Задание 4](@next)
