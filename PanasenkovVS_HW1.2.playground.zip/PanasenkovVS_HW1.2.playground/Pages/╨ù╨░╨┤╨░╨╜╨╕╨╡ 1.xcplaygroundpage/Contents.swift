let piShortcut: Float = 3.14, randomNumber: Float = 42.0
var finalSum = Double(piShortcut + randomNumber)
print(finalSum)

//: [Далее: Задание 2](@next)
