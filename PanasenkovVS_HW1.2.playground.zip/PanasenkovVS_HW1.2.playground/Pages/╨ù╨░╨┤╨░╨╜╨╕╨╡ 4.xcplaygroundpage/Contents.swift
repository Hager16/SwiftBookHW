//: [Назад: Задание 3](@previous)
let depositSizeRub = 14000000
let depositRate = 8
let yearsBeforeWithdraw = 7
let generalRate = depositRate * yearsBeforeWithdraw
let eventualMoney = depositSizeRub * generalRate / 100
let finalData = "Выплата по депозиту без капитализации процентов суммой \(depositSizeRub) рублей при ставке \(depositRate)% годовых через \(yearsBeforeWithdraw) лет будет \(generalRate)% или \(eventualMoney) рублей"
print(finalData)
//: КОНЕЦ))
