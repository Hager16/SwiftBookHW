//: [Назад: Задание 1](@previous)
let numberOne = 17
let numberTwo = 3
let result = numberOne / numberTwo
let remainder = numberOne % numberTwo
let simpleResultString = "При делении \(numberOne) на \(numberTwo) результат равен \(result), остаток равен \(remainder)"
let mathCorrectString = "Результат деления \(numberOne) на \(numberTwo) равен \(result) \(remainder)/\(numberTwo)"
print(simpleResultString)
print(mathCorrectString)
//: [Далее: Задание 3](@next)
