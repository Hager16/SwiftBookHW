// 2.1


/// Композиция
struct AudioFile {
    /// Название
    let title: String
    /// Альбом
    let album: String
    /// Автор
    let author: String
    /// Длина в секундах
    let lengthSeconds: Int
}

/// Аудиоплеер
class AudioPlayer {
    /// Направление проигрывания
    private enum PlayDirection {
        case next
        case previous
        case current
    }
    /// Кол-во композиций
    var numberOfCompositions: Int { compositions.count }
    /// Массив композиций (плейлист)
    private var compositions: [AudioFile] = []
    /// Индекс текущей композиции
    private var currentCompositionIndex: Int = 0
    /// Текущее устройство для вывода звука, если nil, то устройство не подключено
    private var currentOutputAudioDevice: OutputAudioDevice?

    /// Подключить устройство для вывода звука
    func setOutputDevice(_ device: OutputAudioDevice?) {
        currentOutputAudioDevice = device
    }
    
    /// Добавить новые треки
    func add(compositions: [AudioFile]) {
        self.compositions.append(contentsOf: compositions)
    }
    
    /// Перемешать плейлист
    func shuffleCompositions() {
        compositions.shuffle()
    }
    
    // MARK: - Проигрывание
    
    /// Включить текущуий трек
    func playCurrentComposition() {
        play(direction: .current)
    }
    
    /// Включить следующий трек
    func playNext() {
        play(direction: .next)
    }

    /// Включить предыдущий трек
    func playPrevious() {
        play(direction: .previous)
    }
    
    /// Играть следующую или предудущую песню в зависимости от playNext
    private func play(direction: PlayDirection) {
        guard compositions.count > 0 else {
            printNoCompositions()
            return
        }
        switch direction {
        case .current:
            // не меняем индекс
            break
        case .next:
            currentCompositionIndex = getNextCompositionIndex()
        case .previous:
            currentCompositionIndex = getPreviousCompositionIndex()
        }
        play(composition: compositions[currentCompositionIndex])
    }
   
    /// Получить следующий индекс песни
    private func getNextCompositionIndex() -> Int {
        currentCompositionIndex + 1 < compositions.count ? currentCompositionIndex + 1 : 0
    }
    
    /// Получить предыдущий индекс песни
    private func getPreviousCompositionIndex() -> Int {
        currentCompositionIndex - 1 >= 0 ? currentCompositionIndex - 1 : compositions.count - 1
    }
    
    /// Проиграть композицию
    private func play(composition: AudioFile) {
        print("Играет песня \"\(composition.title)\" из альбома \"\(composition.album)\", исполнитель \"\(composition.author)\"")
        currentOutputAudioDevice?.playSound(withLengthInSeconds: composition.lengthSeconds)
    }
    
    /// Вывести информацию о том, что композиций нет
    private func printNoCompositions() {
        print("Композиции не найдены")
    }
}

// 2.2

/// Протокол устройства для вывода звука
protocol OutputAudioDevice {
    /// Проиграть звук с длительностью
    func playSound(withLengthInSeconds length: Int)
}

/// Выходное устройство - Наушники
class Headphones: OutputAudioDevice {
    func playSound(withLengthInSeconds length: Int) {
        print("В наушниках проигрывается неизвестный звук длительностью \(length) с.")
    }
}

/// Выходное устройство - Колонки
class Loudspeakers: OutputAudioDevice {
    func playSound(withLengthInSeconds length: Int) {
        print("На колонках проигрывается неизвестный звук длительностью \(length) с.")
    }
}


// 2.3

// Создать объект класса проигрыватель(AudioPlayer)

let myAudioPlayer = AudioPlayer()

// Добавить в него 3 любые песни addCompositions, пример песни: AudioFile(title: "Anesthetize", album: "Fear of a Blank Planet", author: "Porcupine Tree", lengthSeconds: 1063)

myAudioPlayer.add(compositions: [
    AudioFile(title: "Golden God", album: "Blum", author: "MGK", lengthSeconds: 193),
    AudioFile(title: "Поворот", album: "Улица 36", author: "Скриптонит", lengthSeconds: 124),
    AudioFile(title: "Good song", album: "Some Album", author: "Some author", lengthSeconds: 1633)
])

// Проиграть 1 песню (и вспомнить, что выходное устройство не подключено :-))

myAudioPlayer.playCurrentComposition() // можно также playNext()

// Подключить к проигрывателю колонки Loudspeakers.

let loudspeakers = Loudspeakers()
myAudioPlayer.setOutputDevice(loudspeakers)

// Перемешать песни (метод shuffleCompositions())

myAudioPlayer.shuffleCompositions()

// Проиграть 5 песен через метод playNext()

myAudioPlayer.playNext()
myAudioPlayer.playNext()
myAudioPlayer.playNext()
myAudioPlayer.playNext()
myAudioPlayer.playNext()

// Вместо колонок подключить наушники Headphones

let headphones = Headphones()
myAudioPlayer.setOutputDevice(headphones)

// Проиграть 2 песни.

myAudioPlayer.playPrevious()
myAudioPlayer.playPrevious()

// Опционально: можно отключить выходное устройство

myAudioPlayer.setOutputDevice(nil)

