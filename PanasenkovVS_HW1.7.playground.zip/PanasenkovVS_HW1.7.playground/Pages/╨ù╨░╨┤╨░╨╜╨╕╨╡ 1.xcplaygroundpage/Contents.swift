import Foundation
class Shape {
    var height: Float = 0
    var width: Float = 0
    var radius: Float = 0
    var square: Float = 0
    var perimeter: Float = 0
    
    init(height: Float, width: Float) {
        self.height = height
        self.width = width
    }
    init(radius: Float) {
        self.radius = radius
    }
    
    func squareOfShape() -> Float {
        return square
    }
    func perimeterOfShape() -> Float {
        return perimeter
    }
}
class Circle: Shape {
    
    override func squareOfShape() -> Float {
        square = Float.pi * radius * radius
        return square
    }
    override func perimeterOfShape() -> Float {
        perimeter = 2 * Float.pi * radius
        return perimeter
    }
    func description() {
        print("Площадь круга равна \(squareOfShape()), периметр (длина) равна \(perimeterOfShape())")
    }
}
class Rectangle: Shape {
    
    override func squareOfShape() -> Float {
        square = height * width
        return square
    }
    override func perimeterOfShape() -> Float {
        perimeter = 2 * width + 2 * height
       return perimeter
    }
    func description() {
        print("Площадь прямоугольника равна \(squareOfShape()), периметр (длина) равна \(perimeterOfShape())")
    }
}
class Ellipse: Shape {
    
    override func squareOfShape() -> Float {
        square = Float.pi * width * height
        return square
    }
    override func perimeterOfShape() -> Float {
        perimeter = 2 * Float.pi * Float(sqrt((width * width + height * height) / 8))
        return perimeter
    }
    func description() {
        print("Площадь эллипса равна \(squareOfShape()), периметр (длина) равна \(perimeterOfShape())")
    }
}
let myCircle = Circle(radius: 5)
let myRectangle = Rectangle(height: 5, width: 8)
let myEllipse = Ellipse(height: 8, width: 9)

myCircle.description()
myRectangle.description()
myEllipse.description()

//: [Далее: Задание 2](@next)
