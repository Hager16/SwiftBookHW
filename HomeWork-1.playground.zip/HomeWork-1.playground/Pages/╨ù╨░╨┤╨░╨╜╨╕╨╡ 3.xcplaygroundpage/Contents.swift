//: [Назад: Задание2](@previous)
import Foundation
let sideAC: Float = 8.0
let sideCB: Float = 6.0
let sideAB: Float = sqrt(pow(sideAC, 2) + pow(sideCB, 2))
let perimeter = sideAC + sideAB + sideCB
let area = 0.5 * sideAC * sideCB
print("Perimeter =", perimeter)
print("Area = ", area)
//: ### КОНЕЦ))
