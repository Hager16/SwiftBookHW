//: [Назад: Задание2](@previous)
import Foundation
let AC: Float = 8.0
let CB: Float = 6.0
let AB: Float = sqrt(pow(AC, 2)+pow(CB, 2))
let perimeter = AC+AB+CB
let area = 0.5*AC*CB
print("Perimeter =", Int(perimeter))
print("Area = ", Int(area))
//: ### КОНЕЦ))
