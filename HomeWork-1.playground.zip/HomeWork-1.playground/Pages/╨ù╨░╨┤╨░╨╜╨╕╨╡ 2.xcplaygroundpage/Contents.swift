//: [Назад: Задание 1](@previous)
let myAge: Int = 20
var myAgeInTenYears: Int = myAge+10
let daysInYear: Float = 365.25
var daysPassed: Float = Float(myAgeInTenYears)*daysInYear
print("Мой возраст \(myAge) лет. Через 10 лет, мне будет \(myAgeInTenYears) лет, с момента моего рождения пройдет \(Int(daysPassed)) дней.")
//: [Далее: Задание 3](@next)
