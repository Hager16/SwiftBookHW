let firstString: String = "I can"
let secondString: String = "code"
let finalString = firstString + " " + secondString + "!"
print(finalString)
//: [Далее: Задание 2](@next)
