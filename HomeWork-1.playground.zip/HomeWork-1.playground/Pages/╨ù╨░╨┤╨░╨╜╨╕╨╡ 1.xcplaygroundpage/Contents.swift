let firstString: String = "I can"
let secondString: String = "code"
print(firstString,secondString+"!")
//: [Далее: Задание 2](@next)
