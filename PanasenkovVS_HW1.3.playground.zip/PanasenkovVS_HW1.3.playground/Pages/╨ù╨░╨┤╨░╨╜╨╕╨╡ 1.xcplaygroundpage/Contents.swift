let goodsQuantity = 20
if goodsQuantity < 10 {
    print(goodsQuantity * 1000)
}
else if goodsQuantity < 20 {
    print(goodsQuantity * 800)
} else {
    print(goodsQuantity * 600)
}
//Вариант ниже точно такой же, но иммет более простую, на мой взгляд, структуру изменения, так как вариьрующиеся цены тоже можно было бы менять в реальной ситуации
//Но таким образом код получается чуть больше по объему 
//let goodsQuantity = 40
//let maxPrice = 1000
//let midPrice = 800
//let minPrice = 600
//if goodsQuantity < 10 {
//    print(goodsQuantity * maxPrice)
//}
//else if goodsQuantity < 20 {
//    print(goodsQuantity * midPrice)
//} else {
//    print(goodsQuantity * minPrice)
//}

//: [Далее: Задание 2](@next)
