//: [Назад: Задание 4](@previous)
let testNumber = "+79281234567"
let rusNumberLenth = 12
let moreThanExpect = 13...
let lessThanExpect = (0..<12)

let numberCharsCount = testNumber.count
let rusVerification = testNumber.hasPrefix("+7")

//:Задание 5.1
switch numberCharsCount {
case rusNumberLenth where rusVerification == true:
    print("Номер Российский")
case rusNumberLenth where rusVerification == false:
    print("Номер не Российский")
case moreThanExpect where rusVerification == false:
    print("Номер не Российский")
case lessThanExpect where rusVerification == false:
    print("Номер не Российский")
case moreThanExpect where rusVerification == true:
    print("Сократите номер на \(numberCharsCount - 12) символ(а/ов)")
case lessThanExpect where rusVerification == true:
    print("Дополните номер на \(12 - numberCharsCount) символ(а/ов)")
default: break
}

//: Задание 5.2
//if numberCharsCount == rusNumberLenth, testNumber.hasPrefix("+7") {
//    print("Номер Российский")
//}
//else if numberCharsCount == rusNumberLenth, !testNumber.hasPrefix("+7") {
//    print("Номер не Российский")
//}
//else if numberCharsCount > rusNumberLenth, !testNumber.hasPrefix("+7") {
//    print("Номер не Российский")
//}
//else if numberCharsCount < rusNumberLenth, !testNumber.hasPrefix("+7") {
//    print("Номер не Российский")
//}
//else if numberCharsCount > rusNumberLenth {
//    print("Сократите номер на \(numberCharsCount - rusNumberLenth) символ(а/ов)")
//}
//else if numberCharsCount < rusNumberLenth {
//    print("Дополните номер на \(rusNumberLenth - numberCharsCount) символ(а/ов)")
//}
//: [Далее: Задание 6](@next)
