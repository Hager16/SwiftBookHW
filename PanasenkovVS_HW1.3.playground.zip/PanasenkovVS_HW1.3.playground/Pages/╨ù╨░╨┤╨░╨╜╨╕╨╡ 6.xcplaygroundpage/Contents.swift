//: [Назад: Задание 5](@previous)
//6.1
enum CalculationType {
    case addition
    case subtraction
    case multiplication
    case division
}
//6.2
let firstNumber = 25
let secondNumber = 4
let calculationType: CalculationType
calculationType = .addition
switch calculationType {
case .addition:
    print("Результат сложения \(firstNumber) и \(secondNumber) равен \(firstNumber + secondNumber)")
    fallthrough
case .division:
    print("Результат вычитания \(firstNumber) и \(secondNumber) равен \(firstNumber - secondNumber)")
    fallthrough
case .multiplication:
    print("Результат умножения \(firstNumber) и \(secondNumber) равен \(firstNumber * secondNumber)")
    fallthrough
case .subtraction:
    print("Результат деления \(firstNumber) на \(secondNumber) равен \(Double(firstNumber / secondNumber))")
}

enum CurrencyUnit {
    case rouble
    case dollar (DollarCountries)
    case euro
    enum DollarCountries: String {
        case USA = "$"
        case Canada = "C$"
        case Australia = "AUD"
    }
}
let canada : CurrencyUnit.DollarCountries = .Canada
let canadaCurrency = canada.rawValue
print(canadaCurrency)
//Протестировал: при смене первой константы на другие кейсы из внутренного перечисления также выводятся обозначения валют других долларовых стран.
//: ### КОНЕЦ)
