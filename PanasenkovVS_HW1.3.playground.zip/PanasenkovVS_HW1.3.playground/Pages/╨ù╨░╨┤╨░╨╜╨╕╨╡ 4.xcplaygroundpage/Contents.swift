//: [Назад: Задание 3](@previous)
let riskLevelA = "Выключить все электрические приборы"
let riskLevelB = "Закрыть входные двери и окна"
let riskLevelC = "Соблюдать спокойствие"
let riskLevel = riskLevelB
switch riskLevel {
case riskLevelA:
    print(riskLevelA)
    fallthrough
case riskLevelB:
    print(riskLevelB)
    fallthrough
case riskLevelC:
    print(riskLevelC)
default:
    print("Everything is allright")
}
//: [Далее: Задание 5](@next)
