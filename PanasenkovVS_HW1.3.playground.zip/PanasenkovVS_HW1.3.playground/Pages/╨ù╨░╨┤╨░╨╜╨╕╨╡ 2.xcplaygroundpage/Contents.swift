//: [Назад: Задание 1](@previous)

//:Ошибка 1
//var userInputAge: String = "34e"
//let userAge: Int = Int(userInputAge)
//: Вторая часть
//var userInputAge: String = "34e"
//let userAge: Int? = Int(userInputAge)
//Равно nil, так как невозможно было преобразовать стринговое значение, но мы задали опциональный тип константе, поэтому компилятор либо присвоил бы ей целочисленное значение, либо она просто осталась бы пустой, как это получилось у нас.
//: Третья часть
//var userInputAge: String = "34"
//let userAge: Int? = Int(userInputAge)
//if userAge != nil {
//    print (userAge)
//}
//: Четвертая часть
//var userInputAge: String = "34e"
//let userAge: Int? = Int(userInputAge)!
//print(userAge)
//Ошибку получаем потому, что уверяем компилятор в наличии целочисленного значения в опционале, хотя его там быть не может, так как допущена ошибка во входных данных
//: [Далее: Задание 3](@next)
