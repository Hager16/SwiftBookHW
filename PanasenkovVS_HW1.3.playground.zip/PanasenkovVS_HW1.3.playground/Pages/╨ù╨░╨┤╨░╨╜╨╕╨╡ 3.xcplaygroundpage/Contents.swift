//: [Назад: Задание 2 ](@previous)
let monthOfBirth = 14
let firstQuarter = 1...3
let secondQuarter = 4...6
let thirdQuarter = 7...9
let fourthQuarter = 10...12
switch monthOfBirth {
case firstQuarter:
    print("I was born in the first quarter of the year")
case secondQuarter:
    print("I was born in the second quarter of the year")
case thirdQuarter:
    print("I was born in the third quarter of the year")
case fourthQuarter:
    print("I was born in the fourth quarter of the year")
default:
    print("I'm from Mars")
}
//: [Далее: Задание 4](@next)
