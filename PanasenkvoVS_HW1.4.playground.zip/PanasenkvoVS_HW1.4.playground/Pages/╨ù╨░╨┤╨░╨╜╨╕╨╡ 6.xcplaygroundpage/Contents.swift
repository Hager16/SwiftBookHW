//: [Назад: Задание 5](@previous)
// Входные данные, которые могут изменяться
let items = ["Раз", "Два"]


// Начало алгоритма
print("Привет")  // O(1)

for _ in items {
    for item1 in items {
        print("subitem 1 \(item1)")
    }
    for item2 in items {
        print(item2)
    }
} // O(nˆ2)

print("36") //O(1)
//1+nˆ2+1 = nˆ2+2
//Отбросив константы, получим: O(nˆ2)
// Конец алгоритма
//: [Далее: Задание 7](@next)
