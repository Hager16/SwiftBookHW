//: [Назад: Задание 3](@previous)
import Foundation
for number in 1 ... 10 {
   let randomNumber = Int.random(in: 1...10)
    if randomNumber == 5 {
        print("Что бы выпало число 5 потребовалось \(number) итерации")
        break
        }
}
//: [Далее: Задание 5](@next)
