//: [Назад: Задание 2](@previous)
let intArray = [3, 5, 34, 15, 3212, 7, 18, 43]
for even in intArray {
    if even % 2 == 0 {
        print(even)
    }
}
for odd in intArray {
    if odd % 2 == 0 {
        continue
    }
    print(odd)
}
//: [Далее: Задание 4](@next)
