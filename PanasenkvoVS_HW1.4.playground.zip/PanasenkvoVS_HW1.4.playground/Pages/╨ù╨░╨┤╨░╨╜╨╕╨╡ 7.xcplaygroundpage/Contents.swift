//: [Назад: Задание 6](@previous)
// Первоначальное решение моё
let a = [3, 7, 9, 8]
var repeats: [Int] = []
var uniques: [Int] = []
for (index, number) in a.enumerated() {
    if a[(a.index(index, offsetBy: 1, limitedBy: a.endIndex) ?? a.endIndex)..<a.endIndex].contains(number) {
        repeats.append(number)
    } else if !repeats.contains(number) {
        uniques.append(number)
    }
}
repeats
uniques
var requiredNumber: Int = 0
if repeats.isEmpty {
    print("No repeats")
} else {
    requiredNumber = repeats.removeLast()
    print(requiredNumber)
}
//Лучшее решение google:
let b = [1, 3, 7, 1, 3, 9, 8]
var numberSet = Set<Int>()
for number in b {
    if numberSet.contains(number) {
        print(number)
        break
    }else{
        numberSet.insert(number)
    }
}
//:### [The End]
