//: [Назад: Задание 4](@previous)
let upGrade = 2
let downGrade = 1
let successHeight = 10
var startHeight = 0
var daysPased = 0
while startHeight < successHeight {
    startHeight += upGrade
    daysPased += 1
    if startHeight < successHeight {
        startHeight -= downGrade
    } else {
        break
}
}
let finalString = "Черепашка доползёт до верха за \(daysPased) дней"
print(finalString)

//: [Далее: Задание 6](@next)

