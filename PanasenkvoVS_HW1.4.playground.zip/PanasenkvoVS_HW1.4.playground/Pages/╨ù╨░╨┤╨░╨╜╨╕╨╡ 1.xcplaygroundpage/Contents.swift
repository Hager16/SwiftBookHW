import Foundation
var depositSizeRub: Double = 500000
let depositRate = 11
let yearsBeforeWithdraw = 5
var profit: Double = 0
var profitSum: Double = 0
for _ in 1...yearsBeforeWithdraw {
    profit = depositSizeRub * Double(depositRate) / 100
    depositSizeRub += profit
    profitSum += profit
}
let finalProfitSum = String(format:"%.2f", profitSum)
let finalDepositSize = String(format:"%.2f", depositSizeRub)
let finalString = "Сумма вклада через \(yearsBeforeWithdraw) лет увеличится на \(finalProfitSum) и составит \(finalDepositSize)"
print(finalString)

//: [Далее: Задание 2](@next)
