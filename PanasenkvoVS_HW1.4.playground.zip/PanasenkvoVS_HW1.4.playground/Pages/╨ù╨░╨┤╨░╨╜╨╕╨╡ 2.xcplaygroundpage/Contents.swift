//: [Назад: Задание 1](@previous)
let base = 5
let power = 7
var answer = 1
if power > 0 {
    for _ in 1...power {
        answer *= base
    }
}
print("\(base) в \(power) степени равно \(answer)")
//: [Далее: Задание 3](@next)
