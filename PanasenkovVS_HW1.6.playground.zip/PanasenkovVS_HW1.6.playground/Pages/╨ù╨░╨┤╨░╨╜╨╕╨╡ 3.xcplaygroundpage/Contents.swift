//: [Назад: Задание 2](@previous)
struct PlayerInChess {
    let name: String
    var wins: Int
    
    func description() {
        print("Player's name is \(name), he got \(wins) wins")
    }
    mutating func addWinns(new: Int){
        wins += new
    }
}
var firstPlayer = PlayerInChess(name: "Vladimir", wins: 21)
firstPlayer.addWinns(new: 5)
firstPlayer.description()
//: [Далее: Задание 4](@next)
