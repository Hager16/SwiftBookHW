import Foundation
class Orange {
    var color: String = ""
    var taste: String = ""
    var radius: Double = 0
    var orangeVolume: Double = 0
    
    init(color: String, taste: String, radius: Double) {
        self.color = color
        self.taste = taste
        self.radius = radius
    }
    func calculateOrangeVolume() -> Double{
        orangeVolume = Double.pi * pow(radius, 3) * (4/3)
        return orangeVolume
    }
}
let someOrange = Orange(color: "Orange", taste: "Sweet", radius: 95)
print("Orange has \(someOrange.color) color and \(someOrange.taste) taste")


//let orangeVolume = Double.pi * pow(someOrange.radius, 3) * (4/3)
//print(orangeVolume)

print(someOrange.calculateOrangeVolume())



//: [Далее: Задние 2](@next)
