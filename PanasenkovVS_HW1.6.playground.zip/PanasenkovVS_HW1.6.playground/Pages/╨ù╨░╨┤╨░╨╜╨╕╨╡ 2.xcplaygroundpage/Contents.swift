//: [Назад: Задание 1](@previous)
struct Car {
    var name: String
    let productionYear: Int
    var horsePower: Int
}
let hondaCRV = Car(name: "Honda CR-V", productionYear: 2010, horsePower: 231)
var hondaCivic = hondaCRV
hondaCivic.name = "Honda civic"
for _ in 1...5 {
    hondaCivic.horsePower += 1
}
print("Мощность двигателя \(hondaCivic.name) составляет \(hondaCivic.horsePower) л.с.")
//: [Далее: Задание 3](@next)
