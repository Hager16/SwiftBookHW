//: [Назад: Задание 3](@previous)
import Foundation
class Employee {
    var salary: Double
    var name: String
    var surname: String
    
    init(salary: Double, name: String, surname: String) {
        self.salary = salary
        self.name = name
        self.surname = surname
    }
}
let namesArray = ["John", "Aaron", "Tim", "Ted", "Steven"]
let surnamesArray = ["Smith", "Dow", "Isaacson", "Pennyworth", "Jankins"]
var employees = [Employee]()
var employee = Employee(salary: 0, name: "", surname: "")
for _ in 1...10 {
    employee = Employee(salary: Double.random(in: 1000...2000), name: namesArray.randomElement() ?? "", surname: surnamesArray.randomElement()!)
    employees.append(employee)
}
for employee in employees {
    print("\(employee.name) \(employee.surname)'salary is $\(employee.salary)")
}
let evenSalaryEmployees = employees.filter {Int($0.salary) % 2 == 0}
for person in evenSalaryEmployees {
    print("\(person.name) \(person.surname)'salary is even")
}

//:### Конец))
