//: [Назад: Задание 1](@previous)
import Foundation
func timeIntervalCount(fromDay day: Int, month: Int, year: Int){
    let currentDate = Date()
    let calendar = Calendar.current
    let dateComponents  = DateComponents(year: year, month: month, day: day)
    
    if let someDateTime = calendar.date(from: dateComponents) {
        let daysPassed = calendar.dateComponents([.day], from: someDateTime, to: currentDate).day ?? 0
        let monthsPassed = calendar.dateComponents([.month], from: someDateTime, to: currentDate).month ?? 0
        let yearsPassed = calendar.dateComponents([.year], from: someDateTime, to: currentDate).year ?? 0
        
        print("\(yearsPassed) years or \(monthsPassed) months or \(daysPassed) days have passed since")
    }
}
timeIntervalCount(fromDay: 16, month: 5, year: 2000)

//: [Далее: Задание 3](@next)
