//: [Назад: Задание 4](@previous)
//Обычная реализация
func fibonacciArray(of numbers: Int) -> [Int] {
    var fibonacci: [Int] = [1, 1]
    (2...numbers).forEach{ number in
        fibonacci.append(fibonacci[number - 1] + fibonacci[number - 2])
    }
    return fibonacci
}
print(fibonacciArray(of: 9))
//рекурсивная реализация
func getFibonacciArray(n: Int) -> [Int] {
    switch n {
    case ...0:
        return []
    case 1:
        return [1]
    case 2:
        return [1, 1]
    default:
        let resultArray = getFibonacciArray(n: n - 1)
        return resultArray + [resultArray[n - 3] + resultArray[n - 2]]
    }
}
print(getFibonacciArray(n: 12))
//: КОНЕЦ
