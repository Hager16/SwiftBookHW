let scoresWithSalavat = ["3:6", "5:5"]
let scoresWithAvangard = ["2:1", "2:3"]
let scoresWithAkbars = ["3:3", "1:2"]
var resultsData = [
    "Салават Юлаев": scoresWithAvangard,
    "Авангард": scoresWithAvangard,
    "АкБарс": scoresWithAkbars
]
for (nameOfTeam, scores) in resultsData {
    for result in scores {
        print("Игра с \(nameOfTeam) - \(result)")
    }
}
//: [Далее: Задание 2](@next)
