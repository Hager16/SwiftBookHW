//: [Назад: Задание 3](@previous)
import Foundation
//4.1
func evenChecker(number: Int) -> Bool {
    return number % 2 == 0
}
evenChecker(number: 63)
//4.2
func threeDivisionChecker(number: Int) -> Bool {
    return number % 3 == 0
}
threeDivisionChecker(number: 69)
//4.3 - 4.4
func risingArray(from firstNumber: Int, to lastNumber: Int) -> [Int] {
    let numbersLine = firstNumber...lastNumber
    var finalArray = [Int]()
    finalArray.append(contentsOf: numbersLine)
    return finalArray
}
risingArray(from: 1, to: 100)
//4.3: "усложненная"
func risingUniqueArray(from number1: Int, to number2: Int) -> [Int] {
    let numbersLine = number1...number2
    var finalArray = [Int]()
    for _ in numbersLine {
        var uniqueRandomNumber = Int.random(in: numbersLine)
        while finalArray.contains(uniqueRandomNumber) {
            uniqueRandomNumber = Int.random(in: numbersLine)
        }
        finalArray.append(uniqueRandomNumber)
    }
    return finalArray
}
risingUniqueArray(from: 3, to: 12)
//4.5
let hundredArray = risingArray(from: 1, to: 100)
var filteredHundredArray = hundredArray.filter {$0 % 2 != 0 && $0 % 3 != 0}
filteredHundredArray
// 4.6 через Int #1
func centuryFromYear(year: Int) -> Int {
    return (year + 99) / 100
}
centuryFromYear(year: 2000)
// 4.6 через Int #1
func centuryCounter(year: Int) -> Int {
    var century = year / 100
    if year % 100 != 0 {
        century += 1
    }
    return century
}
centuryCounter(year: 2000)
//: [Далее: Задание 5](@next)
