//: [Назад: Задание 2](@previous)
import Foundation
let moneyInWallet = [50, 200, 500, 500, 1000, 2000, 5000]
func moneyCounter(array: [Int]) -> Int {
    var sumOfMoney = 0
    for number in array {
        sumOfMoney += number
    }
    return sumOfMoney
}
print(moneyCounter(array: moneyInWallet))
//: [Далее: Здание 4](@next)
